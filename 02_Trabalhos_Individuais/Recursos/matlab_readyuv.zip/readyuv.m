function [Y,U,V] = readyuv_fast( arq, W, H, F, FRM)
%FRM = 0 ==> YUV 4:0:0
%FRM = 1 ==> YUV 4:4:4
%FRM = 2 ==> YUV 4:2:0

%arq
fp = fopen(arq,'rb');

if fp == 0
disp('Could not open file');
end

if FRM == 0

Y = uint8(zeros(H,W,F));    
for f = 1:F
    Y(:,:,f) = fread(fp, [W,H], 'uchar')';
end
fclose(fp);
U = 0;
V = 0;
return;

end

Y = uint8(zeros(H,W,F));
U = uint8(zeros(H/FRM,W/FRM,F));
V = U;

for f = 1:F
Y(:,:,f) = fread(fp,[W,H],'uchar')';
U(:,:,f) = fread(fp,[W/FRM,H/FRM],'uchar')';
V(:,:,f) = fread(fp,[W/FRM,H/FRM],'uchar')';
end

fclose(fp);
